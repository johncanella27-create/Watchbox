import React, { useState, useEffect, useMemo } from "react";

const C = {
  navy:      "#13172a",
  navyMid:   "#1c2236",
  navyLow:   "#252d44",
  navyDeep:  "#0d1020",
  gold:      "#c9a84c",
  goldLight: "#e2c47a",
  goldFaint: "#c9a84c1a",
  goldBorder:"#c9a84c33",
  cream:     "#f0ebe0",
  creamDim:  "#d8d0be",
  grey:      "#7a8199",
  green:     "#4a9e6e",
  amber:     "#c9843c",
  red:       "#b54a40",
};

const styles = `
  @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=Montserrat:wght@300;400;500;600&display=swap');
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: ${C.navy}; color: ${C.cream}; font-family: 'Montserrat', system-ui, sans-serif; min-height: 100vh;
    background-image: radial-gradient(ellipse 80% 60% at 50% -10%, #1e2a4a 0%, transparent 70%); }
  .app { max-width: 1000px; margin: 0 auto; padding: 0 20px 100px; }

  /* ── Sweep animation ── */
  @keyframes sweep { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }

  /* ── Nav tabs ── */
  .nav { display: flex; gap: 0; margin-bottom: 0; border-bottom: 1px solid ${C.navyLow}; }
  .nav-tab { background: none; border: none; color: ${C.grey}; font-family: 'Montserrat', sans-serif;
    font-size: 9px; font-weight: 600; letter-spacing: 2.5px; text-transform: uppercase;
    padding: 14px 20px; cursor: pointer; border-bottom: 2px solid transparent; margin-bottom: -1px;
    transition: all 0.2s; }
  .nav-tab:hover { color: ${C.cream}; }
  .nav-tab.active { color: ${C.gold}; border-bottom-color: ${C.gold}; }

  /* ── Hero Header ── */
  .header { position: relative; padding: 40px 0 28px; margin-bottom: 0; overflow: hidden; }
  .header::after { content: ''; position: absolute; bottom: 0; left: 0; right: 0; height: 1px;
    background: linear-gradient(90deg, transparent, ${C.gold}66, ${C.gold}, ${C.gold}66, transparent); }
  .header-inner { position: relative; z-index: 2; display: flex; align-items: center; gap: 36px; }
  .header-text { flex: 1; }
  .header-eyebrow { font-family: 'Montserrat', sans-serif; font-size: 9px; font-weight: 500;
    letter-spacing: 4px; text-transform: uppercase; color: ${C.gold}; margin-bottom: 10px;
    display: flex; align-items: center; gap: 10px; }
  .header-eyebrow::before, .header-eyebrow::after { content: ''; display: inline-block;
    width: 24px; height: 1px; background: ${C.gold}88; }
  .header-title { font-family: 'Cormorant Garamond', serif; font-size: 52px; font-weight: 300;
    color: ${C.cream}; line-height: 1; letter-spacing: 2px; text-transform: uppercase; }
  .header-title span { color: ${C.gold}; font-style: italic; font-weight: 400; }
  .header-sub { font-size: 11px; font-weight: 300; letter-spacing: 2px; color: ${C.grey};
    margin-top: 10px; text-transform: uppercase; }
  .header-actions { display: flex; gap: 10px; align-items: center; margin-top: 20px; flex-wrap: wrap; }
  .engrave-line { display: flex; align-items: center; gap: 12px; margin: 6px 0 16px; opacity: 0.4; }
  .engrave-line::before, .engrave-line::after { content: ''; flex: 1; height: 1px; background: linear-gradient(90deg, transparent, ${C.gold}); }
  .engrave-line::after { background: linear-gradient(90deg, ${C.gold}, transparent); }
  .engrave-diamond { width: 5px; height: 5px; border: 1px solid ${C.gold}; transform: rotate(45deg); flex-shrink: 0; }

  /* ── Buttons ── */
  .btn { font-family: 'Montserrat', sans-serif; font-size: 10px; font-weight: 600; letter-spacing: 2px;
    text-transform: uppercase; border: none; cursor: pointer; padding: 11px 22px; transition: all 0.25s; }
  .btn-primary { background: linear-gradient(135deg, ${C.gold}, ${C.goldLight} 50%, ${C.gold}); color: ${C.navyDeep};
    font-weight: 700; box-shadow: 0 2px 16px ${C.gold}33; }
  .btn-primary:hover { box-shadow: 0 4px 24px ${C.gold}55; transform: translateY(-1px); }
  .btn-primary:disabled { opacity: 0.5; transform: none; cursor: not-allowed; }
  .btn-ghost { background: transparent; color: ${C.grey}; border: 1px solid ${C.navyLow}; }
  .btn-ghost:hover { border-color: ${C.gold}88; color: ${C.gold}; }
  .btn-danger { background: transparent; color: ${C.red}; border: 1px solid transparent;
    font-size: 10px; padding: 8px 12px; letter-spacing: 1.5px; }
  .btn-danger:hover { border-color: ${C.red}66; background: ${C.red}11; }
  .btn-sm { padding: 7px 14px; font-size: 10px; }
  .btn-wear { background: ${C.goldFaint}; color: ${C.gold}; border: 1px solid ${C.goldBorder};
    font-size: 10px; letter-spacing: 1.5px; padding: 8px 16px; }
  .btn-wear:hover { background: ${C.gold}25; border-color: ${C.gold}66; }
  .btn-wearing { background: linear-gradient(135deg, ${C.gold}, ${C.goldLight}); color: ${C.navyDeep};
    font-size: 10px; letter-spacing: 1.5px; padding: 8px 16px; font-weight: 700; border: none;
    box-shadow: 0 2px 12px ${C.gold}44; }

  /* ── Stats bar ── */
  .stats-bar { display: flex; gap: 0; margin: 28px 0; background: ${C.navyMid}; border: 1px solid ${C.navyLow};
    border-top: 2px solid ${C.gold}; flex-wrap: wrap; }
  .stat { display: flex; flex-direction: column; gap: 5px; padding: 18px 24px; flex: 1; min-width: 110px;
    border-right: 1px solid ${C.navyLow}; }
  .stat:last-child { border-right: none; }
  .stat-value { font-family: 'Cormorant Garamond', serif; font-size: 30px; font-weight: 300; color: ${C.cream}; line-height: 1; }
  .stat-label { font-size: 9px; font-weight: 500; letter-spacing: 2px; text-transform: uppercase; color: ${C.grey}; }
  .stat-value.amber { color: ${C.amber}; }
  .stat-value.green { color: ${C.green}; }

  /* ── Collection list ── */
  .collection { display: flex; flex-direction: column; gap: 2px; }
  .card { background: ${C.navyMid}; position: relative; overflow: hidden; transition: transform 0.2s, box-shadow 0.2s;
    border: 1px solid ${C.navyLow}; display: flex; align-items: center; cursor: pointer; }
  .card:hover { transform: translateY(-2px); box-shadow: 0 8px 32px ${C.navyDeep}cc; }
  .card-thumb { width: 72px; height: 72px; flex-shrink: 0; overflow: hidden; background: ${C.navyLow};
    display: flex; align-items: center; justify-content: center; position: relative; }
  .card-thumb img { width: 100%; height: 100%; object-fit: cover; display: block; }
  .card-worn-bar { position: absolute; bottom: 0; left: 0; right: 0; height: 3px;
    background: linear-gradient(90deg, ${C.gold}, ${C.goldLight}); }
  .card-idle-bar { position: absolute; bottom: 0; left: 0; right: 0; height: 3px; background: ${C.amber}; }
  .card-info { flex: 1; padding: 0 14px; min-width: 0; }
  .card-brand { font-size: 9px; font-weight: 600; letter-spacing: 2.5px; text-transform: uppercase; color: ${C.gold}; margin-bottom: 3px; }
  .card-model { font-family: 'Cormorant Garamond', serif; font-size: 18px; font-weight: 300; color: ${C.cream};
    line-height: 1.1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .card-ref { font-size: 10px; color: ${C.grey}; margin-top: 2px; letter-spacing: 0.5px; }
  .card-alert { font-size: 9px; color: ${C.amber}; margin-top: 3px; letter-spacing: 0.5px; }
  .card-service-alert { font-size: 9px; color: ${C.red}; margin-top: 3px; letter-spacing: 0.5px; }
  .card-right { display: flex; flex-direction: column; align-items: flex-end; gap: 6px; padding: 0 14px; flex-shrink: 0; }

  /* ── Wishlist card ── */
  .wish-card { background: ${C.navyMid}; border: 1px solid ${C.navyLow}; border-left: 2px solid ${C.gold}44;
    padding: 14px 16px; display: flex; align-items: center; gap: 14px; cursor: pointer; transition: background 0.2s; }
  .wish-card:hover { background: ${C.navyLow}; }
  .wish-brand { font-size: 9px; font-weight: 600; letter-spacing: 2.5px; text-transform: uppercase; color: ${C.gold}; }
  .wish-model { font-family: 'Cormorant Garamond', serif; font-size: 18px; font-weight: 300; color: ${C.cream}; }
  .wish-price { font-size: 11px; color: ${C.grey}; margin-top: 2px; }
  .wish-notes { font-size: 11px; color: ${C.creamDim}; margin-top: 4px; font-weight: 300; }

  /* ── Modal ── */
  .modal-backdrop { position: fixed; inset: 0; background: rgba(7,9,20,0.88); backdrop-filter: blur(4px);
    display: flex; align-items: center; justify-content: center; z-index: 100; padding: 20px; }
  .modal { background: ${C.navyMid}; border: 1px solid ${C.navyLow}; border-top: 2px solid ${C.gold};
    width: 100%; max-width: 520px; max-height: 90vh; overflow-y: auto; padding: 32px; position: relative; }
  .modal-title { font-family: 'Cormorant Garamond', serif; font-size: 30px; font-weight: 300;
    color: ${C.cream}; margin-bottom: 24px; letter-spacing: 1px; }
  .form-group { margin-bottom: 18px; }
  .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
  label { display: block; font-size: 9px; font-weight: 600; letter-spacing: 2.5px;
    text-transform: uppercase; color: ${C.grey}; margin-bottom: 7px; }
  input, textarea, select { width: 100%; background: ${C.navyLow}; border: 1px solid ${C.navyLow};
    border-bottom: 1px solid ${C.grey}44; color: ${C.cream}; font-family: 'Montserrat', system-ui, sans-serif;
    font-size: 13px; font-weight: 300; padding: 9px 11px; outline: none; transition: all 0.2s; }
  input:focus, textarea:focus, select:focus { border-color: ${C.gold}88; border-bottom-color: ${C.gold}; background: ${C.navyDeep}; }
  input::placeholder, textarea::placeholder { color: ${C.grey}66; }
  textarea { resize: vertical; min-height: 72px; }
  select option { background: ${C.navyLow}; }
  .modal-actions { display: flex; gap: 10px; margin-top: 24px; flex-wrap: wrap; }

  /* ── Service history ── */
  .service-list { display: flex; flex-direction: column; gap: 5px; margin-top: 8px; }
  .service-item { display: flex; align-items: center; gap: 10px; background: ${C.navyLow};
    border-left: 2px solid ${C.gold}55; padding: 9px 11px; font-size: 12px; }
  .service-date { color: ${C.gold}; font-size: 10px; font-weight: 500; letter-spacing: 1px; min-width: 88px; }
  .service-desc { color: ${C.cream}; flex: 1; font-weight: 300; }
  .service-remove { background: none; border: none; color: ${C.grey}; cursor: pointer; font-size: 14px; }
  .service-remove:hover { color: ${C.red}; }
  .service-add-row { display: flex; gap: 8px; margin-top: 8px; flex-wrap: wrap; }
  .service-add-row input { flex: 1; min-width: 120px; }

  /* ── Empty state ── */
  .empty { text-align: center; padding: 60px 20px; color: ${C.grey}; }
  .empty-title { font-family: 'Cormorant Garamond', serif; font-size: 32px; font-weight: 300;
    color: ${C.cream}; margin-bottom: 10px; letter-spacing: 1px; }
  .empty-sub { font-size: 12px; font-weight: 300; letter-spacing: 1px; margin-bottom: 24px; }

  /* ── Divider ── */
  .divider { border: none; height: 1px; background: linear-gradient(90deg, transparent, ${C.navyLow}, transparent); margin: 18px 0; }

  /* ── Filter bar ── */
  .filter-bar { display: flex; gap: 10px; margin: 20px 0; align-items: center; flex-wrap: wrap; }
  .filter-bar select { width: auto; font-size: 11px; padding: 7px 11px; }
  .filter-label { font-size: 9px; font-weight: 600; letter-spacing: 2.5px; text-transform: uppercase; color: ${C.grey}; }
  .search-input { flex: 1; min-width: 140px; max-width: 220px; }

  /* ── Wear log ── */
  .wear-log-entry { display: flex; justify-content: space-between; align-items: center;
    padding: 7px 11px; background: ${C.navyLow}; font-size: 11px; margin-bottom: 3px;
    border-left: 1px solid ${C.gold}33; }
  .wear-log-date { color: ${C.gold}; font-weight: 500; }
  .wear-log-remove { background: none; border: none; color: ${C.grey}; cursor: pointer; }
  .wear-log-remove:hover { color: ${C.red}; }

  /* ── Stats page ── */
  .stats-page { display: flex; flex-direction: column; gap: 28px; padding-top: 28px; }
  .stats-section-title { font-size: 9px; font-weight: 600; letter-spacing: 3px; text-transform: uppercase;
    color: ${C.gold}; margin-bottom: 14px; }
  .bar-chart { display: flex; flex-direction: column; gap: 10px; }
  .bar-row { display: flex; align-items: center; gap: 12px; }
  .bar-label { font-size: 11px; color: ${C.creamDim}; min-width: 140px; white-space: nowrap;
    overflow: hidden; text-overflow: ellipsis; flex-shrink: 0; }
  .bar-track { flex: 1; height: 6px; background: ${C.navyLow}; position: relative; }
  .bar-fill { height: 100%; background: linear-gradient(90deg, ${C.gold}, ${C.goldLight}); transition: width 0.6s ease; }
  .bar-val { font-size: 11px; color: ${C.grey}; min-width: 28px; text-align: right; }
  .month-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(90px, 1fr)); gap: 8px; }
  .month-cell { background: ${C.navyMid}; border: 1px solid ${C.navyLow}; padding: 12px 10px; text-align: center; }
  .month-name { font-size: 9px; letter-spacing: 2px; text-transform: uppercase; color: ${C.grey}; margin-bottom: 6px; }
  .month-count { font-family: 'Cormorant Garamond', serif; font-size: 26px; font-weight: 300; color: ${C.cream}; }
  .streak-box { background: ${C.navyMid}; border: 1px solid ${C.navyLow}; border-top: 2px solid ${C.gold};
    padding: 20px 24px; display: flex; gap: 32px; flex-wrap: wrap; }
  .alert-list { display: flex; flex-direction: column; gap: 8px; }
  .alert-item { display: flex; align-items: center; gap: 12px; padding: 10px 14px; background: ${C.navyMid};
    border: 1px solid ${C.navyLow}; border-left: 2px solid ${C.amber}; font-size: 12px; }
  .alert-item.service { border-left-color: ${C.red}; }
  .alert-item-name { flex: 1; color: ${C.cream}; }
  .alert-item-detail { color: ${C.grey}; font-size: 10px; }

  /* ── Section panel ── */
  .panel { background: ${C.navyMid}; border: 1px solid ${C.navyLow}; padding: 20px 22px; }
  .panel-title { font-family: 'Cormorant Garamond', serif; font-size: 22px; font-weight: 300;
    color: ${C.cream}; margin-bottom: 16px; }

  /* ── Export row ── */
  .export-row { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 8px; }

  @media (max-width: 520px) {
    .header-title { font-size: 38px; }
    .form-row { grid-template-columns: 1fr; }
    .stat { min-width: 45%; }
    .header-inner { flex-direction: column; gap: 16px; }
    .nav-tab { padding: 12px 12px; font-size: 8px; }
    .bar-label { min-width: 90px; }
  }
`;

// ─── SVG Components ─────────────────────────────────────────────
function WearDial({ days, size = 36 }) {
  const pct = Math.min(days / Math.max(days, 365), 1);
  const r = (size / 2) - 4;
  const cx = size / 2, cy = size / 2;
  const circ = 2 * Math.PI * r;
  const dash = pct * circ;
  const id = `dg${size}`;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <defs>
        <linearGradient id={id} x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor={C.gold} /><stop offset="100%" stopColor={C.goldLight} />
        </linearGradient>
      </defs>
      <circle cx={cx} cy={cy} r={r} fill="none" stroke={C.navyLow} strokeWidth="2.5"
        style={{ transform: `rotate(-90deg)`, transformOrigin: `${cx}px ${cy}px` }} />
      {days > 0 && <circle cx={cx} cy={cy} r={r} fill="none" stroke={`url(#${id})`} strokeWidth="2.5"
        strokeDasharray={`${dash} ${circ}`} style={{ transform: `rotate(-90deg)`, transformOrigin: `${cx}px ${cy}px`, transition: "stroke-dasharray 0.6s ease" }} />}
      <circle cx={cx} cy={cy} r="2" fill={C.gold} opacity="0.7" />
    </svg>
  );
}

function MiniWatchIcon() {
  return (
    <svg width="32" height="32" viewBox="0 0 32 32" opacity="0.4">
      <rect x="11" y="2" width="10" height="5" rx="1.5" fill={C.navyLow} stroke={C.grey} strokeWidth="0.75"/>
      <rect x="11" y="25" width="10" height="5" rx="1.5" fill={C.navyLow} stroke={C.grey} strokeWidth="0.75"/>
      <circle cx="16" cy="16" r="11" fill={C.navyDeep} stroke={C.grey} strokeWidth="1"/>
      <circle cx="16" cy="16" r="8" fill="none" stroke={C.gold + "33"} strokeWidth="0.5"/>
      <line x1="16" y1="10" x2="16" y2="16" stroke={C.cream+"cc"} strokeWidth="1.5" strokeLinecap="round"/>
      <line x1="16" y1="16" x2="20" y2="18" stroke={C.cream+"cc"} strokeWidth="1" strokeLinecap="round"/>
      <circle cx="16" cy="16" r="1.5" fill={C.gold} opacity="0.8"/>
    </svg>
  );
}

function ThumbImage({ url, style, full }) {
  const [err, setErr] = React.useState(false);
  React.useEffect(() => { setErr(false); }, [url]);
  if (!url || err) return <MiniWatchIcon />;
  if (full) {
    return <img src={url} alt="" style={style || {width:"100%",height:190,objectFit:"cover",display:"block",marginBottom:16}} onError={() => setErr(true)} />;
  }
  return <img src={url} alt="" style={{width:"100%",height:"100%",objectFit:"cover",display:"block"}} onError={() => setErr(true)} />;
}

// ─── HeroWatchFace — sweeping second hand via CSS animation ─────
function HeroWatchFace() {
  const [time, setTime] = React.useState(new Date());

  // Compute initial offset so the animation starts at the correct position.
  // Negative animationDelay fast-forwards the CSS animation to the right second.
  const [secOffset, setSecOffset] = React.useState(() => {
    const now = new Date();
    return now.getSeconds() + now.getMilliseconds() / 1000;
  });

  // Tick every second for H/M hands only
  React.useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  // Re-sync sweep on tab focus restore
  React.useEffect(() => {
    const resync = () => {
      if (document.visibilityState === 'visible') {
        const now = new Date();
        setSecOffset(now.getSeconds() + now.getMilliseconds() / 1000);
      }
    };
    document.addEventListener('visibilitychange', resync);
    return () => document.removeEventListener('visibilitychange', resync);
  }, []);

  const cx = 70, cy = 70, r = 56;
  const s = time.getSeconds(), m = time.getMinutes(), h = time.getHours() % 12;
  const mA = ((m + s / 60) / 60) * 2 * Math.PI - Math.PI / 2;
  const hA = ((h + m / 60) / 12) * 2 * Math.PI - Math.PI / 2;

  const ticks = Array.from({length:60},(_,i)=>{
    const a=(i/60)*2*Math.PI-Math.PI/2, maj=i%5===0, oR=r-2, iR=maj?r-11:r-5;
    return {x1:cx+oR*Math.cos(a),y1:cy+oR*Math.sin(a),x2:cx+iR*Math.cos(a),y2:cy+iR*Math.sin(a),maj};
  });

  return (
    <svg width="140" height="158" viewBox="0 0 140 158" style={{flexShrink:0,opacity:0.9}}>
      <defs>
        <linearGradient id="hg" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor={C.gold}/><stop offset="50%" stopColor={C.goldLight}/><stop offset="100%" stopColor={C.gold}/>
        </linearGradient>
        <radialGradient id="db" cx="40%" cy="35%">
          <stop offset="0%" stopColor="#1e2845"/><stop offset="100%" stopColor={C.navyDeep}/>
        </radialGradient>
        <filter id="gw"><feGaussianBlur stdDeviation="1.5" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
      </defs>
      <rect x="48" y="2" width="44" height="14" rx="4" fill={C.navyLow} stroke={C.gold+"33"} strokeWidth="0.75"/>
      <rect x="48" y="142" width="44" height="14" rx="4" fill={C.navyLow} stroke={C.gold+"33"} strokeWidth="0.75"/>
      <rect x="128" y="61" width="9" height="16" rx="3" fill={C.navyLow} stroke={C.gold+"55"} strokeWidth="0.75"/>
      <circle cx={cx} cy={cy} r={r+8} fill="none" stroke="url(#hg)" strokeWidth="1.5"/>
      <circle cx={cx} cy={cy} r={r+3} fill={C.navyLow}/>
      <circle cx={cx} cy={cy} r={r} fill="url(#db)"/>
      <circle cx={cx} cy={cy} r={r-3} fill="none" stroke={C.gold+"18"} strokeWidth="0.5"/>
      {ticks.map((t,i)=><line key={i} x1={t.x1} y1={t.y1} x2={t.x2} y2={t.y2} stroke={t.maj?C.gold+"cc":C.grey+"55"} strokeWidth={t.maj?"1.5":"0.75"}/>)}
      {[{n:"XII",a:-Math.PI/2},{n:"III",a:0},{n:"VI",a:Math.PI/2},{n:"IX",a:Math.PI}].map(({n,a})=>(
        <text key={n} x={cx+(r-20)*Math.cos(a)} y={cy+(r-20)*Math.sin(a)} textAnchor="middle" dominantBaseline="central"
          fill={C.gold+"bb"} fontSize="7.5" fontFamily="Cormorant Garamond,serif" fontWeight="400">{n}</text>
      ))}
      <text x={cx} y={cy-17} textAnchor="middle" fill={C.cream+"55"} fontSize="5.5" fontFamily="Montserrat,sans-serif" fontWeight="500" letterSpacing="3">WATCHBOX</text>

      {/* Hour & minute hands — JS-driven, tick each second */}
      <line x1={cx-6*Math.cos(hA)} y1={cy-6*Math.sin(hA)} x2={cx+r*0.48*Math.cos(hA)} y2={cy+r*0.48*Math.sin(hA)} stroke={C.cream} strokeWidth="3.5" strokeLinecap="round" filter="url(#gw)"/>
      <line x1={cx-8*Math.cos(mA)} y1={cy-8*Math.sin(mA)} x2={cx+r*0.7*Math.cos(mA)} y2={cy+r*0.7*Math.sin(mA)} stroke={C.cream} strokeWidth="2" strokeLinecap="round" filter="url(#gw)"/>

      {/* Second hand — drawn at 12 o'clock, rotated via CSS sweep animation.
          key={secOffset} forces remount (and animation restart) on re-sync. */}
      <g
        key={secOffset}
        style={{
          transformOrigin: `${cx}px ${cy}px`,
          transformBox: 'view-box',
          animation: 'sweep 60s linear infinite',
          animationDelay: `-${secOffset}s`,
        }}
      >
        <line
          x1={cx} y1={cy + 12}
          x2={cx} y2={cy - r * 0.8}
          stroke={C.gold} strokeWidth="1" strokeLinecap="round" filter="url(#gw)"
        />
      </g>

      <circle cx={cx} cy={cy} r="5" fill={C.navyLow} stroke="url(#hg)" strokeWidth="1"/>
      <circle cx={cx} cy={cy} r="2.5" fill={C.gold}/>
    </svg>
  );
}

// ─── Helpers ──────────────────────────────────────────────────
function today() { return new Date().toISOString().slice(0,10); }
function fmt(d) { if (!d) return "—"; return new Date(d+"T00:00:00").toLocaleDateString("en-US",{year:"numeric",month:"short",day:"numeric"}); }
function fmtShort(d) { if (!d) return "—"; return new Date(d+"T00:00:00").toLocaleDateString("en-US",{month:"short",year:"numeric"}); }
function currency(v) { if (!v) return "—"; return new Intl.NumberFormat("en-US",{style:"currency",currency:"USD",maximumFractionDigits:0}).format(v); }
function isWornToday(w) { return w.wearLog?.includes(today()); }
function daysSince(dateStr) {
  if (!dateStr) return null;
  const diff = new Date() - new Date(dateStr+"T00:00:00");
  return Math.floor(diff / 86400000);
}

// ─── Storage ──────────────────────────────────────────────────
const STORAGE_KEY = "watchbox_v2";

function load() {
  try {
    const raw = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (raw?.watches) return raw;
    const v1 = JSON.parse(localStorage.getItem("watchbox_v1"));
    if (v1) return { watches: v1, wishlist: [] };
  } catch {}
  return { watches: [], wishlist: [] };
}

function save(data) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); } catch {}
}

// ─── Main App ─────────────────────────────────────────────────
export default function App() {
  const [data, setData] = useState(() => load());
  const watches = data.watches || [];
  const wishlist = data.wishlist || [];
  const [tab, setTab] = useState("collection");
  const [modal, setModal] = useState(null);
  const [selected, setSelected] = useState(null);
  const [sort, setSort] = useState("added");
  const [search, setSearch] = useState("");
  const [rotationDays, setRotationDays] = useState(() => parseInt(localStorage.getItem("wb_rotation") || "14"));
  const [saveStatus, setSaveStatus] = useState(null);

  useEffect(() => {
    save(data);
    setSaveStatus('saved');
    const t = setTimeout(() => setSaveStatus(null), 1500);
    return () => clearTimeout(t);
  }, [data]);
  useEffect(() => { localStorage.setItem("wb_rotation", rotationDays); }, [rotationDays]);

  function setWatches(fn) { setData(d => ({ ...d, watches: typeof fn === "function" ? fn(d.watches) : fn })); }
  function setWishlist(fn) { setData(d => ({ ...d, wishlist: typeof fn === "function" ? fn(d.wishlist) : fn })); }

  // ── Watch CRUD ──
  function addWatch(w) { setWatches(p => [{ ...w, id: Date.now(), wearLog: [], addedAt: today() }, ...p]); setModal(null); }
  function updateWatch(id, u) { setWatches(p => p.map(w => w.id===id ? {...w,...u} : w)); if(selected?.id===id) setSelected(s=>({...s,...u})); }
  function deleteWatch(id) { setWatches(p => p.filter(w => w.id!==id)); setModal(null); setSelected(null); }
  function toggleWear(id) {
    const t = today();
    setWatches(p => p.map(w => { if(w.id!==id) return w; const log=w.wearLog||[]; return {...w, wearLog: log.includes(t)?log.filter(d=>d!==t):[...log,t]}; }));
    if(selected?.id===id) { const log=selected.wearLog||[]; setSelected(s=>({...s, wearLog:log.includes(today())?log.filter(d=>d!==today()):[...log,today()]})); }
  }
  function removeWearEntry(id, date) {
    setWatches(p => p.map(w => w.id!==id ? w : {...w, wearLog:(w.wearLog||[]).filter(d=>d!==date)}));
    if(selected?.id===id) setSelected(s=>({...s, wearLog:(s.wearLog||[]).filter(d=>d!==date)}));
  }

  // ── Wishlist CRUD ──
  function addWish(w) { setWishlist(p => [{ ...w, id: Date.now() }, ...p]); setModal(null); }
  function deleteWish(id) { setWishlist(p => p.filter(w => w.id!==id)); setModal(null); setSelected(null); }
  function promoteWish(wish) {
    deleteWish(wish.id);
    setModal("add");
    setSelected({ brand: wish.brand, model: wish.model, notes: wish.notes, purchasePrice: wish.targetPrice });
  }

  // ── Computed ──
  const totalDays = watches.reduce((s,w)=>s+(w.wearLog?.length||0), 0);
  const wornToday = watches.filter(isWornToday).length;
  const totalValue = watches.reduce((s,w)=>s+(parseFloat(w.purchasePrice)||0), 0);
  const idleWatches = watches.filter(w => { const last = [...(w.wearLog||[])].sort().pop(); return last ? daysSince(last) >= rotationDays : daysSince(w.addedAt) >= rotationDays; });
  const serviceDue = watches.filter(w => { const last = [...(w.serviceHistory||[])].sort((a,b)=>a.date>b.date?-1:1)[0]; return last ? daysSince(last.date) >= 365*4 : daysSince(w.addedAt) >= 365*4; });

  const streak = useMemo(() => {
    const allDates = new Set(watches.flatMap(w=>w.wearLog||[]));
    let count=0, d=new Date();
    while(true) {
      const k=d.toISOString().slice(0,10);
      if(!allDates.has(k)) { if(count===0 && k!==today()) break; break; }
      count++; d.setDate(d.getDate()-1);
    }
    return count;
  }, [watches]);

  const sorted = useMemo(() => {
    let list = [...watches];
    if(search) { const q=search.toLowerCase(); list=list.filter(w=>(w.brand+w.model+w.reference).toLowerCase().includes(q)); }
    if(sort==="most-worn") list.sort((a,b)=>(b.wearLog?.length||0)-(a.wearLog?.length||0));
    else if(sort==="least-worn") list.sort((a,b)=>(a.wearLog?.length||0)-(b.wearLog?.length||0));
    else if(sort==="brand") list.sort((a,b)=>(a.brand||"").localeCompare(b.brand||""));
    else if(sort==="value") list.sort((a,b)=>(b.purchasePrice||0)-(a.purchasePrice||0));
    else list.sort((a,b)=>b.id-a.id);
    return list;
  }, [watches, sort, search]);

  // ── Export ──
  const [copied, setCopied] = useState(null);
  function copyTo(text, label) {
    navigator.clipboard.writeText(text).then(() => { setCopied(label); setTimeout(() => setCopied(null), 2500); });
  }
  function exportJSON() { copyTo(JSON.stringify(data, null, 2), "json"); }
  function exportCSV() {
    const rows = [["Brand","Model","Reference","Purchase Price","Purchase Date","Days Worn","Last Worn","Added"]];
    watches.forEach(w => {
      const last = [...(w.wearLog||[])].sort().pop()||"";
      rows.push([w.brand,w.model,w.reference,w.purchasePrice||"",w.purchaseDate||"",w.wearLog?.length||0,last,w.addedAt||""]);
    });
    const csv = rows.map(r=>r.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(",")).join("\n");
    copyTo(csv, "csv");
  }
  function importJSON(e) {
    const file = e.target.files?.[0]; if(!file) return;
    const r = new FileReader(); r.onload = ev => {
      try {
        const d = JSON.parse(ev.target.result);
        if(d.watches) setData(d); else if(Array.isArray(d)) setData({watches:d,wishlist:[]});
        setCopied("imported"); setTimeout(() => setCopied(null), 2500);
      } catch { setCopied("error"); setTimeout(() => setCopied(null), 2500); }
    };
    r.readAsText(file); e.target.value="";
  }
  const tabs = [
    { id:"collection", label:"Collection" },
    { id:"stats", label:"Statistics" },
    { id:"wishlist", label:"Wishlist" },
    { id:"settings", label:"Settings" },
  ];
  return (
    <>
      <style>{styles}</style>
      <div className="app">
        {/* Header */}
        <header className="header">
          <div className="header-inner">
            <div className="header-text">
              <div className="header-eyebrow">Horological Journal</div>
              <h1 className="header-title">Watch<span>box</span></h1>
              <div className="engrave-line"><div className="engrave-diamond"/></div>
              <p className="header-sub">
                {watches.length} {watches.length===1?"timepiece":"timepieces"} · {currency(totalValue)} collection value
                {saveStatus === 'saved' && <span style={{marginLeft:12,color:C.green,fontSize:9,letterSpacing:"1.5px"}}>✓ saved</span>}
                {saveStatus === 'error' && <span style={{marginLeft:12,color:C.red,fontSize:9,letterSpacing:"1.5px"}}>⚠ save failed</span>}
              </p>
              <div className="header-actions">
                <button className="btn btn-primary" onClick={()=>{setSelected(null);setModal("add")}}>+ Add Watch</button>
                {streak>1 && <span style={{fontSize:11,color:C.gold,letterSpacing:"1px"}}>🔥 {streak}-day streak</span>}
              </div>
            </div>
            <HeroWatchFace />
          </div>
        </header>

        {/* Nav */}
        <nav className="nav">
          {tabs.map(t=><button key={t.id} className={`nav-tab${tab===t.id?" active":""}`} onClick={()=>setTab(t.id)}>
            {t.label}
            {t.id==="wishlist"&&wishlist.length>0?` (${wishlist.length})`:""}
            {t.id==="settings"&&(idleWatches.length+serviceDue.length)>0?" ⚠":""}
          </button>)}
        </nav>

        {/* ── COLLECTION TAB ── */}
        {tab==="collection" && (
          <>
            <div className="stats-bar">
              <div className="stat"><span className="stat-value">{watches.length}</span><span className="stat-label">Watches</span></div>
              <div className="stat"><span className="stat-value">{totalDays}</span><span className="stat-label">Total Days Worn</span></div>
              <div className="stat"><span className={`stat-value${wornToday>0?" green":""}`}>{wornToday}</span><span className="stat-label">Worn Today</span></div>
              <div className="stat"><span className={`stat-value${idleWatches.length>0?" amber":""}`}>{idleWatches.length}</span><span className="stat-label">Idle Watches</span></div>
              {totalValue>0&&<div className="stat"><span className="stat-value" style={{fontSize:20,paddingTop:4}}>{currency(totalValue)}</span><span className="stat-label">Collection Value</span></div>}
            </div>

            {watches.length > 1 && (
              <div className="filter-bar">
                <input className="search-input" placeholder="Search..." value={search} onChange={e=>setSearch(e.target.value)} />
                <span className="filter-label">Sort</span>
                <select value={sort} onChange={e=>setSort(e.target.value)}>
                  <option value="added">Recent</option>
                  <option value="most-worn">Most Worn</option>
                  <option value="least-worn">Least Worn</option>
                  <option value="brand">Brand A–Z</option>
                  <option value="value">Value</option>
                </select>
              </div>
            )}

            {watches.length===0 ? (
              <div className="empty">
                <MiniWatchIcon />
                <div className="empty-title" style={{marginTop:16}}>Your Watchbox is empty</div>
                <p className="empty-sub">Add your first watch to start tracking.</p>
                <button className="btn btn-primary" onClick={()=>setModal("add")}>Add First Watch</button>
              </div>
            ) : (
              <div className="collection">
                {sorted.map(w => {
                  const lastWorn = [...(w.wearLog||[])].sort().pop();
                  const idle = lastWorn ? daysSince(lastWorn) >= rotationDays : daysSince(w.addedAt) >= rotationDays;
                  const lastSvc = [...(w.serviceHistory||[])].sort((a,b)=>a.date>b.date?-1:1)[0];
                  const svcDue = lastSvc ? daysSince(lastSvc.date) >= 365*4 : daysSince(w.addedAt) >= 365*4;
                  const worn = isWornToday(w);
                  return (
                    <div key={w.id} className="card" onClick={()=>{setSelected(w);setModal("detail")}}>
                      <div className="card-thumb">
                        <ThumbImage url={w.photoUrl}/>
                        {worn && <div className="card-worn-bar"/>}
                        {!worn && idle && <div className="card-idle-bar"/>}
                      </div>
                      <div className="card-info">
                        <div className="card-brand">{w.brand||"Unknown"}</div>
                        <div className="card-model">{w.model||"Unnamed"}</div>
                        {w.reference && <div className="card-ref">Ref. {w.reference}</div>}
                        {!worn && idle && <div className="card-alert">⚠ Not worn in {lastWorn?daysSince(lastWorn):daysSince(w.addedAt)}d</div>}
                        {svcDue && <div className="card-service-alert">🔧 Service due</div>}
                      </div>
                      <div className="card-right" onClick={e=>e.stopPropagation()}>
                        <div style={{display:"flex",alignItems:"center",gap:7}}>
                          <WearDial days={w.wearLog?.length||0} size={36}/>
                          <div style={{textAlign:"right"}}>
                            <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:18,fontWeight:300,color:C.cream,lineHeight:1}}>{w.wearLog?.length||0}</div>
                            <div style={{fontSize:8,letterSpacing:"1.5px",textTransform:"uppercase",color:C.grey}}>days</div>
                          </div>
                        </div>
                        <button className={worn?"btn btn-wearing":"btn btn-wear"} onClick={()=>toggleWear(w.id)}
                          style={{fontSize:9,padding:"5px 10px",letterSpacing:"1px",whiteSpace:"nowrap"}}>
                          {worn?"✓ Today":"Wear"}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </>
        )}

        {/* ── STATS TAB ── */}
        {tab==="stats" && <StatsPage watches={watches} streak={streak}/>}

        {/* ── WISHLIST TAB ── */}
        {tab==="wishlist" && (
          <div style={{paddingTop:28}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20}}>
              <span style={{fontFamily:"'Cormorant Garamond',serif",fontSize:26,fontWeight:300,color:C.cream}}>Wish List</span>
              <button className="btn btn-primary btn-sm" onClick={()=>{setSelected(null);setModal("addWish")}}>+ Add to List</button>
            </div>
            {wishlist.length===0 ? (
              <div className="empty">
                <div className="empty-title">No watches on your list</div>
                <p className="empty-sub">Track the watches you want to acquire.</p>
                <button className="btn btn-primary" onClick={()=>setModal("addWish")}>Add First</button>
              </div>
            ) : (
              <div style={{display:"flex",flexDirection:"column",gap:2}}>
                {wishlist.map(w=>(
                  <div key={w.id} className="wish-card" onClick={()=>{setSelected(w);setModal("wishDetail")}}>
                    <div style={{flex:1}}>
                      <div className="wish-brand">{w.brand||"Unknown"}</div>
                      <div className="wish-model">{w.model||"Unnamed"}</div>
                      {w.targetPrice && <div className="wish-price">Target: {currency(w.targetPrice)}</div>}
                      {w.notes && <div className="wish-notes">{w.notes}</div>}
                    </div>
                    <span style={{color:C.grey,fontSize:18}}>›</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ── SETTINGS TAB ── */}
        {tab==="settings" && (
          <div style={{paddingTop:28,display:"flex",flexDirection:"column",gap:24}}>
            {(idleWatches.length>0||serviceDue.length>0) && (
              <div className="panel">
                <div className="panel-title">Alerts</div>
                <div className="alert-list">
                  {idleWatches.map(w=>{
                    const last=[...(w.wearLog||[])].sort().pop();
                    return <div key={w.id} className="alert-item"><span className="alert-item-name">{w.brand} {w.model}</span><span className="alert-item-detail">Not worn in {last?daysSince(last):daysSince(w.addedAt)} days</span></div>;
                  })}
                  {serviceDue.map(w=><div key={w.id} className="alert-item service"><span className="alert-item-name">{w.brand} {w.model}</span><span className="alert-item-detail">Service overdue</span></div>)}
                </div>
              </div>
            )}

            <div className="panel">
              <div className="panel-title">Rotation Reminder</div>
              <p style={{fontSize:12,color:C.grey,marginBottom:14,fontWeight:300}}>Flag watches not worn within this many days.</p>
              <div style={{display:"flex",alignItems:"center",gap:12}}>
                <input type="number" value={rotationDays} onChange={e=>setRotationDays(Math.max(1,parseInt(e.target.value)||1))} style={{width:80}} min={1}/>
                <span style={{fontSize:12,color:C.grey}}>days</span>
              </div>
            </div>
            <div className="panel">
              <div className="panel-title">Export & Backup</div>
              <p style={{fontSize:12,color:C.grey,marginBottom:6,fontWeight:300}}>Copy your data to clipboard, then paste into a text file to save. Import a JSON backup to restore.</p>
              {copied==="imported" && <p style={{fontSize:11,color:C.green,marginBottom:10}}>✓ Collection imported successfully</p>}
              {copied==="error" && <p style={{fontSize:11,color:C.red,marginBottom:10}}>✗ Invalid file — could not import</p>}
              <div className="export-row">
                <button className="btn btn-ghost btn-sm" onClick={exportJSON}>{copied==="json" ? "✓ Copied JSON!" : "Copy JSON"}</button>
                <button className="btn btn-ghost btn-sm" onClick={exportCSV}>{copied==="csv" ? "✓ Copied CSV!" : "Copy CSV"}</button>
                <label className="btn btn-ghost btn-sm" style={{cursor:"pointer",display:"inline-block",padding:"7px 14px"}}>
                  ⬆ Import JSON
                  <input type="file" accept=".json" style={{display:"none"}} onChange={importJSON}/>
                </label>
              </div>
            </div>

            <div className="panel">
              <div className="panel-title">Monthly Wear Goals</div>
              <p style={{fontSize:12,color:C.grey,marginBottom:14,fontWeight:300}}>Set a target number of wear-days per watch per month.</p>
              <div style={{display:"flex",flexDirection:"column",gap:10}}>
                {watches.map(w=>{
                  const thisMonth = (w.wearLog||[]).filter(d=>d.startsWith(today().slice(0,7))).length;
                  const goal = w.monthlyGoal||0;
                  const pct = goal>0 ? Math.min(thisMonth/goal,1) : 0;
                  return (
                    <div key={w.id} style={{display:"flex",alignItems:"center",gap:12}}>
                      <span style={{fontSize:11,color:C.creamDim,minWidth:160,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{w.brand} {w.model}</span>
                      <div style={{flex:1,height:5,background:C.navyLow,position:"relative"}}>
                        <div style={{height:"100%",width:`${pct*100}%`,background:pct>=1?C.green:C.gold,transition:"width 0.4s"}}/>
                      </div>
                      <span style={{fontSize:11,color:C.grey,minWidth:32,textAlign:"right"}}>{thisMonth}/{goal||"?"}</span>
                      <input type="number" min={0} max={31} value={goal||""} placeholder="—"
                        onChange={e=>updateWatch(w.id,{monthlyGoal:parseInt(e.target.value)||0})}
                        style={{width:52,fontSize:12,padding:"4px 6px"}}/>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ── Modals ── */}
      {modal==="add" && <WatchFormModal title="Add Watch" initial={selected||{}} onSave={addWatch} onClose={()=>setModal(null)}/>}
      {modal==="edit" && selected && <WatchFormModal title="Edit Watch" initial={selected} onSave={d=>{updateWatch(selected.id,d);setModal("detail");}} onClose={()=>setModal("detail")}/>}
      {modal==="detail" && selected && (() => {
        const w = watches.find(x=>x.id===selected.id)||selected;
        return <DetailModal watch={w} onClose={()=>{setModal(null);setSelected(null);}} onEdit={()=>{setSelected(w);setModal("edit");}} onDelete={()=>deleteWatch(w.id)} onWear={()=>toggleWear(w.id)} onRemoveWear={date=>removeWearEntry(w.id,date)}/>;
      })()}
      {modal==="addWish" && <WishFormModal title="Add to Wishlist" initial={{}} onSave={addWish} onClose={()=>setModal(null)}/>}
      {modal==="wishDetail" && selected && (() => {
        const w = wishlist.find(x=>x.id===selected.id)||selected;
        return <WishDetailModal wish={w} onClose={()=>{setModal(null);setSelected(null);}} onDelete={()=>deleteWish(w.id)} onPromote={()=>promoteWish(w)}/>;
      })()}
    </>
  );
}

// ─── Stats Page ────────────────────────────────────────────────
function StatsPage({ watches, streak }) {
  const monthCounts = useMemo(() => {
    const map = {};
    watches.forEach(w=>(w.wearLog||[]).forEach(d=>{ const k=d.slice(0,7); map[k]=(map[k]||0)+1; }));
    return Object.entries(map).sort((a,b)=>a[0]>b[0]?-1:1).slice(0,12).reverse();
  }, [watches]);

  const byWatch = useMemo(() =>
    [...watches].sort((a,b)=>(b.wearLog?.length||0)-(a.wearLog?.length||0)).slice(0,10),
    [watches]
  );
  const maxDays = byWatch[0]?.wearLog?.length||1;
  const totalDays = watches.reduce((s,w)=>s+(w.wearLog?.length||0),0);
  const avgPerWatch = watches.length ? Math.round(totalDays/watches.length) : 0;
  const totalValue = watches.reduce((s,w)=>s+(parseFloat(w.purchasePrice)||0),0);

  if(watches.length===0) return <div className="empty" style={{paddingTop:60}}><div className="empty-title">No data yet</div><p className="empty-sub">Add watches and log wear days to see statistics.</p></div>;

  return (
    <div className="stats-page">
      <div className="streak-box">
        {[
          ["Total Wear Days", totalDays],
          ["Avg per Watch", avgPerWatch+"d"],
          ["Current Streak", streak+"d 🔥"],
          ["Collection", currency(totalValue)],
        ].map(([l,v])=>(
          <div key={l} className="stat" style={{border:"none",padding:"0 24px 0 0",minWidth:100}}>
            <span className="stat-value" style={{fontSize:28}}>{v}</span>
            <span className="stat-label">{l}</span>
          </div>
        ))}
      </div>

      <div>
        <div className="stats-section-title">Wear Days by Watch</div>
        <div className="bar-chart">
          {byWatch.map(w=>(
            <div key={w.id} className="bar-row">
              <span className="bar-label">{w.brand} {w.model}</span>
              <div className="bar-track"><div className="bar-fill" style={{width:`${((w.wearLog?.length||0)/maxDays)*100}%`}}/></div>
              <span className="bar-val">{w.wearLog?.length||0}</span>
            </div>
          ))}
        </div>
      </div>

      {monthCounts.length>0 && (
        <div>
          <div className="stats-section-title">Wear Days by Month</div>
          <div className="month-grid">
            {monthCounts.map(([k,v])=>(
              <div key={k} className="month-cell">
                <div className="month-name">{new Date(k+"-01").toLocaleDateString("en-US",{month:"short",year:"2-digit"})}</div>
                <div className="month-count">{v}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div>
        <div className="stats-section-title">Last Worn</div>
        <div className="bar-chart">
          {[...watches].sort((a,b)=>{
            const la=[...(a.wearLog||[])].sort().pop()||a.addedAt||"";
            const lb=[...(b.wearLog||[])].sort().pop()||b.addedAt||"";
            return la<lb?-1:1;
          }).map(w=>{
            const last=[...(w.wearLog||[])].sort().pop();
            const d = last?daysSince(last):null;
            return (
              <div key={w.id} className="bar-row">
                <span className="bar-label">{w.brand} {w.model}</span>
                <span style={{fontSize:11,color:d==null?C.grey:d>30?C.red:d>14?C.amber:C.green}}>
                  {last ? `${d}d ago` : "Never worn"}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ─── Detail Modal ──────────────────────────────────────────────
function DetailModal({ watch: w, onClose, onEdit, onDelete, onWear, onRemoveWear }) {
  const worn = isWornToday(w);
  const [confirmDelete, setConfirmDelete] = React.useState(false);
  const sortedLog = [...(w.wearLog||[])].sort((a,b)=>b.localeCompare(a));
  const lastSvc = [...(w.serviceHistory||[])].sort((a,b)=>a.date>b.date?-1:1)[0];
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={e=>e.stopPropagation()} style={{maxWidth:540}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:16}}>
          <div>
            <div style={{fontSize:9,fontWeight:600,letterSpacing:"3px",textTransform:"uppercase",color:C.gold,marginBottom:4}}>{w.brand}</div>
            <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:28,fontWeight:300,color:C.cream}}>{w.model}</div>
            {w.reference && <div style={{color:C.grey,fontSize:11,marginTop:3}}>Ref. {w.reference}</div>}
          </div>
          <button className="btn btn-ghost btn-sm" onClick={onClose}>✕</button>
        </div>

        {w.photoUrl && <ThumbImage url={w.photoUrl} style={{width:"100%",height:190,objectFit:"cover",display:"block",marginBottom:16}} full/>}

        <div style={{display:"flex",gap:20,alignItems:"center",marginBottom:16,padding:"14px 18px",background:C.navyLow}}>
          <WearDial days={w.wearLog?.length||0} size={52}/>
          <div>
            <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:32,fontWeight:300,lineHeight:1}}>{w.wearLog?.length||0}</div>
            <div style={{fontSize:9,letterSpacing:"2px",textTransform:"uppercase",color:C.grey}}>Total Days Worn</div>
          </div>
          <div style={{marginLeft:"auto"}}>
            <button className={worn?"btn btn-wearing":"btn btn-wear"} onClick={onWear}>{worn?"✓ Wearing Today":"Wear Today"}</button>
          </div>
        </div>

        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"10px 20px",marginBottom:16}}>
          {[["Purchase Price",currency(w.purchasePrice)],["Purchase Date",fmt(w.purchaseDate)],["Added to Watchbox",fmt(w.addedAt)],["Last Service",lastSvc?fmt(lastSvc.date):"None recorded"]].map(([l,v])=>(
            <div key={l}><div style={{fontSize:9,letterSpacing:"2px",textTransform:"uppercase",color:C.grey,marginBottom:3}}>{l}</div><div style={{fontSize:13,color:C.cream,fontWeight:300}}>{v}</div></div>
          ))}
        </div>
        {w.monthlyGoal>0 && (() => {
          const thisMonth=(w.wearLog||[]).filter(d=>d.startsWith(today().slice(0,7))).length;
          const pct=Math.min(thisMonth/w.monthlyGoal,1);
          return <div style={{marginBottom:16}}><div style={{fontSize:9,letterSpacing:"2px",textTransform:"uppercase",color:C.grey,marginBottom:6}}>Monthly Goal — {thisMonth}/{w.monthlyGoal} days</div><div style={{height:5,background:C.navyLow}}><div style={{height:"100%",width:`${pct*100}%`,background:pct>=1?C.green:C.gold,transition:"width 0.4s"}}/></div></div>;
        })()}
        {w.notes && <div style={{marginBottom:16}}><div style={{fontSize:9,letterSpacing:"2px",textTransform:"uppercase",color:C.grey,marginBottom:5}}>Notes</div><div style={{fontSize:12,color:C.creamDim,lineHeight:1.6,fontWeight:300}}>{w.notes}</div></div>}

        <hr className="divider"/>

        <div style={{marginBottom:16}}>
          <div style={{fontSize:9,letterSpacing:"2px",textTransform:"uppercase",color:C.grey,marginBottom:8}}>Service History</div>
          {(!w.serviceHistory||w.serviceHistory.length===0) ? <div style={{fontSize:12,color:C.grey}}>No service records.</div> : (
            <div className="service-list">{w.serviceHistory.map((s,i)=><div key={i} className="service-item"><span className="service-date">{fmt(s.date)}</span><span className="service-desc">{s.desc}</span></div>)}</div>
          )}
        </div>

        <hr className="divider"/>

        <div style={{marginBottom:20}}>
          <div style={{fontSize:9,letterSpacing:"2px",textTransform:"uppercase",color:C.grey,marginBottom:8}}>Wear Log ({sortedLog.length})</div>
          {sortedLog.length===0 ? <div style={{fontSize:12,color:C.grey}}>No entries yet.</div> : (
            <div style={{maxHeight:160,overflowY:"auto"}}>
              {sortedLog.map(d=><div key={d} className="wear-log-entry"><span className="wear-log-date">{fmt(d)}</span><button className="wear-log-remove" onClick={()=>onRemoveWear(d)}>✕</button></div>)}
            </div>
          )}
        </div>

        <div style={{display:"flex",gap:10,flexWrap:"wrap",alignItems:"center"}}>
          <button className="btn btn-primary btn-sm" onClick={onEdit}>Edit Watch</button>
          {!confirmDelete
            ? <button className="btn btn-danger btn-sm" onClick={()=>setConfirmDelete(true)}>Remove from Watchbox</button>
            : <div style={{display:"flex",alignItems:"center",gap:8,background:C.navyLow,padding:"7px 12px",border:`1px solid ${C.red}44`}}>
                <span style={{fontSize:11,color:C.creamDim}}>Are you sure?</span>
                <button className="btn btn-danger btn-sm" style={{border:`1px solid ${C.red}`}} onClick={onDelete}>Yes, remove</button>
                <button className="btn btn-ghost btn-sm" onClick={()=>setConfirmDelete(false)}>Cancel</button>
              </div>
          }
        </div>
      </div>
    </div>
  );
}

// ─── Wish Detail Modal ─────────────────────────────────────────
function WishDetailModal({ wish: w, onClose, onDelete, onPromote }) {
  const [confirm, setConfirm] = React.useState(false);
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={e=>e.stopPropagation()} style={{maxWidth:440}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:20}}>
          <div>
            <div style={{fontSize:9,fontWeight:600,letterSpacing:"3px",textTransform:"uppercase",color:C.gold,marginBottom:4}}>{w.brand}</div>
            <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:28,fontWeight:300,color:C.cream}}>{w.model}</div>
          </div>
          <button className="btn btn-ghost btn-sm" onClick={onClose}>✕</button>
        </div>
        {w.reference && <div style={{color:C.grey,fontSize:11,marginBottom:10}}>Ref. {w.reference}</div>}
        {w.targetPrice && <div style={{marginBottom:10}}><span style={{fontSize:9,letterSpacing:"2px",textTransform:"uppercase",color:C.grey}}>Target Price</span><div style={{fontSize:20,fontFamily:"'Cormorant Garamond',serif",fontWeight:300}}>{currency(w.targetPrice)}</div></div>}
        {w.notes && <div style={{fontSize:12,color:C.creamDim,marginBottom:16,fontWeight:300,lineHeight:1.6}}>{w.notes}</div>}
        <div style={{display:"flex",gap:10,flexWrap:"wrap",alignItems:"center",marginTop:16}}>
          <button className="btn btn-primary btn-sm" onClick={onPromote}>✓ Mark as Purchased</button>
          {!confirm
            ? <button className="btn btn-danger btn-sm" onClick={()=>setConfirm(true)}>Remove</button>
            : <div style={{display:"flex",gap:8,alignItems:"center",background:C.navyLow,padding:"7px 12px",border:`1px solid ${C.red}44`}}>
                <span style={{fontSize:11,color:C.creamDim}}>Sure?</span>
                <button className="btn btn-danger btn-sm" style={{border:`1px solid ${C.red}`}} onClick={onDelete}>Yes</button>
                <button className="btn btn-ghost btn-sm" onClick={()=>setConfirm(false)}>No</button>
              </div>
          }
        </div>
      </div>
    </div>
  );
}

// ─── Watch Form Modal ──────────────────────────────────────────
function WatchFormModal({ title, initial={}, onSave, onClose }) {
  const [f, setF] = useState({
    brand:initial.brand||"", model:initial.model||"", reference:initial.reference||"",
    purchasePrice:initial.purchasePrice||"", purchaseDate:initial.purchaseDate||"",
    photoUrl:initial.photoUrl||"", notes:initial.notes||"", serviceHistory:initial.serviceHistory||[],
  });
  const [svcDate,setSvcDate]=useState(""); const [svcDesc,setSvcDesc]=useState("");
  const [photoMode,setPhotoMode]=useState(initial.photoUrl?"preview":"url");
  const [camStream,setCamStream]=useState(null); const [camErr,setCamErr]=useState("");
  const videoRef=React.useRef(null); const canvasRef=React.useRef(null); const fileRef=React.useRef(null);

  function set(k,v){setF(p=>({...p,[k]:v}));}

  async function startCam(){setCamErr("");try{const s=await navigator.mediaDevices.getUserMedia({video:{facingMode:"environment"}});setCamStream(s);setPhotoMode("camera");setTimeout(()=>{if(videoRef.current)videoRef.current.srcObject=s;},50);}catch{setCamErr("Camera unavailable.");}}
  function stopCam(){if(camStream){camStream.getTracks().forEach(t=>t.stop());setCamStream(null);}setPhotoMode(f.photoUrl?"preview":"url");}
  function capture(){const v=videoRef.current,c=canvasRef.current;if(!v||!c)return;c.width=v.videoWidth;c.height=v.videoHeight;c.getContext("2d").drawImage(v,0,0);set("photoUrl",c.toDataURL("image/jpeg",0.85));stopCam();setPhotoMode("preview");}
  function handleFile(e){const file=e.target.files?.[0];if(!file)return;const r=new FileReader();r.onload=ev=>{set("photoUrl",ev.target.result);setPhotoMode("preview");};r.readAsDataURL(file);e.target.value="";}

  React.useEffect(()=>{return()=>{if(camStream)camStream.getTracks().forEach(t=>t.stop());};},[camStream]);

  function addSvc(){if(!svcDesc.trim())return;set("serviceHistory",[...f.serviceHistory,{date:svcDate||today(),desc:svcDesc.trim()}]);setSvcDate("");setSvcDesc("");}
  function rmSvc(i){set("serviceHistory",f.serviceHistory.filter((_,idx)=>idx!==i));}
  function submit(){if(!f.model.trim())return;if(camStream)camStream.getTracks().forEach(t=>t.stop());onSave({...f,purchasePrice:f.purchasePrice?parseFloat(f.purchasePrice):null});}

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={e=>e.stopPropagation()}>
        <div className="modal-title">{title}</div>
        <div className="form-row">
          <div className="form-group"><label>Brand</label><input placeholder="e.g. Rolex" value={f.brand} onChange={e=>set("brand",e.target.value)}/></div>
          <div className="form-group"><label>Model *</label><input placeholder="e.g. Submariner" value={f.model} onChange={e=>set("model",e.target.value)}/></div>
        </div>
        <div className="form-group"><label>Reference Number</label><input placeholder="e.g. 126610LN" value={f.reference} onChange={e=>set("reference",e.target.value)}/></div>
        <div className="form-row">
          <div className="form-group"><label>Purchase Price (USD)</label><input type="number" placeholder="0" value={f.purchasePrice} onChange={e=>set("purchasePrice",e.target.value)}/></div>
          <div className="form-group"><label>Purchase Date</label><input type="date" value={f.purchaseDate} onChange={e=>set("purchaseDate",e.target.value)}/></div>
        </div>

        <div className="form-group">
          <label>Photo</label>
          {f.photoUrl && photoMode!=="camera" && (
            <div style={{marginBottom:10,position:"relative"}}>
              <img src={f.photoUrl} alt="preview" style={{width:"100%",maxHeight:160,objectFit:"cover",display:"block"}}/>
              <button onClick={()=>{set("photoUrl","");setPhotoMode("url");}} style={{position:"absolute",top:6,right:6,background:"rgba(0,0,0,0.6)",border:"none",color:C.cream,cursor:"pointer",padding:"3px 8px",fontSize:11}}>✕</button>
            </div>
          )}
          {photoMode==="camera" && (
            <div style={{marginBottom:10}}>
              <video ref={videoRef} autoPlay playsInline style={{width:"100%",maxHeight:200,objectFit:"cover",background:C.navyLow,display:"block"}}/>
              <canvas ref={canvasRef} style={{display:"none"}}/>
              <div style={{display:"flex",gap:8,marginTop:8}}>
                <button className="btn btn-primary btn-sm" onClick={capture}>📷 Capture</button>
                <button className="btn btn-ghost btn-sm" onClick={stopCam}>Cancel</button>
              </div>
            </div>
          )}
          {camErr && <div style={{color:C.red,fontSize:11,marginBottom:8}}>{camErr}</div>}
          {photoMode!=="camera" && (
            <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
              {!!navigator.mediaDevices?.getUserMedia && <button className="btn btn-ghost btn-sm" onClick={startCam}>📷 Camera</button>}
              <button className="btn btn-ghost btn-sm" onClick={()=>fileRef.current?.click()}>⬆ Upload</button>
              {!f.photoUrl && <button className="btn btn-ghost btn-sm" onClick={()=>setPhotoMode("url-input")}>🔗 URL</button>}
              <input ref={fileRef} type="file" accept="image/*" style={{display:"none"}} onChange={handleFile}/>
            </div>
          )}
          {photoMode==="url-input" && <input placeholder="https://..." value={f.photoUrl.startsWith("data:")?"":(f.photoUrl||"")} onChange={e=>set("photoUrl",e.target.value)} style={{marginTop:8}}/>}
        </div>

        <div className="form-group"><label>Notes</label><textarea placeholder="Dial variant, provenance, condition…" value={f.notes} onChange={e=>set("notes",e.target.value)}/></div>

        <hr className="divider"/>
        <div className="form-group">
          <label>Service History</label>
          {f.serviceHistory.length>0 && (
            <div className="service-list" style={{marginBottom:8}}>
              {f.serviceHistory.map((s,i)=><div key={i} className="service-item"><span className="service-date">{fmt(s.date)}</span><span className="service-desc">{s.desc}</span><button className="service-remove" onClick={()=>rmSvc(i)}>✕</button></div>)}
            </div>
          )}
          <div className="service-add-row">
            <input type="date" value={svcDate} onChange={e=>setSvcDate(e.target.value)} style={{maxWidth:140}}/>
            <input placeholder="Service description" value={svcDesc} onChange={e=>setSvcDesc(e.target.value)}/>
            <button className="btn btn-ghost btn-sm" onClick={addSvc}>Add</button>
          </div>
        </div>

        <div className="modal-actions">
          <button className="btn btn-primary" onClick={submit}>Save Watch</button>
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
        </div>
      </div>
    </div>
  );
}

// ─── Wish Form Modal ───────────────────────────────────────────
function WishFormModal({ title, initial={}, onSave, onClose }) {
  const [f, setF] = useState({ brand:initial.brand||"", model:initial.model||"", reference:initial.reference||"", targetPrice:initial.targetPrice||"", notes:initial.notes||"" });
  function set(k,v){setF(p=>({...p,[k]:v}));}
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={e=>e.stopPropagation()} style={{maxWidth:440}}>
        <div className="modal-title">{title}</div>
        <div className="form-row">
          <div className="form-group"><label>Brand</label><input placeholder="e.g. Patek Philippe" value={f.brand} onChange={e=>set("brand",e.target.value)}/></div>
          <div className="form-group"><label>Model *</label><input placeholder="e.g. Nautilus" value={f.model} onChange={e=>set("model",e.target.value)}/></div>
        </div>
        <div className="form-row">
          <div className="form-group"><label>Reference</label><input placeholder="e.g. 5711/1A" value={f.reference} onChange={e=>set("reference",e.target.value)}/></div>
          <div className="form-group"><label>Target Price (USD)</label><input type="number" placeholder="0" value={f.targetPrice} onChange={e=>set("targetPrice",e.target.value)}/></div>
        </div>
        <div className="form-group"><label>Notes</label><textarea placeholder="Why you want it, where to find it…" value={f.notes} onChange={e=>set("notes",e.target.value)}/></div>
        <div className="modal-actions">
          <button className="btn btn-primary" onClick={()=>{if(!f.model.trim())return;onSave({...f,targetPrice:f.targetPrice?parseFloat(f.targetPrice):null});}}>Save</button>
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
        </div>
      </div>
    </div>
  );
}
